<template>
  <h1>404: Page Not Found</h1>
</template>

<script>
export default {
  name: "NotFoundPage",
};
</script>

<style scoped>
/* scoped means css style will ONLY affect this file */
h1 {
  text-align: center;
}
</style>