# back-end

## Project setup (running on port 8000)
```
> cd back-end
```

```
> npm install
```

### Compiles and hot-reloads for development
```
> npm run dev
```